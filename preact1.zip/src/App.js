import React, { useState, useEffect } from "react";
import "./App.css";
import Shelf from "./routepages/Shelf";
import Search from "./routepages/Search";
import { getAll, update ,search } from "./BooksAPI";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import {Link, } from "react-router-dom";


function App() {
  const [bookDetails, setbookDetails] = useState([]);


  useEffect(() => {
    const books = async () => {
      const res = await getAll();
      setbookDetails(res);
    };
    books();
    
  }, []);

    const bookUdate = async (book, shelf) => {
      await update(book, shelf);
  
      window.location.reload(true);
    };
 
  const searchHandler = async (query, maxResults) => {
        console.log("حمادة");
      const res = await search(query, maxResults);
      setbookDetails(res);
      console.log(res);
  }



  return (
    <div className="app">
      <BrowserRouter>
        <Routes>
          <Route
            exact
            path="/"
            element={
              <Shelf bookDetails={bookDetails} bookUdate={bookUdate}/>
            }
          />
          <Route
            exact
            path="/Search"
            element={<Search bookDetails={bookDetails}  searchHandler={searchHandler}  setbookDetails={setbookDetails}  />}
          />
        </Routes>
        <div className="open-search">
          <Link to="/Search">Add a book</Link>
   
        </div>
      </BrowserRouter>
    </div>
  );
}
export default App;
